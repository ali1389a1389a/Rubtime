from .utils import get_fancy_time
import time

class RubTime:
    def __init__(self, token):
        self.token = token

    def change_channel_name(self, guid, name):
        pass

    def change_channel_bio(self, guid, bio):
        pass

    def change_channel_name_bio(self, guid, name, bio):
        pass

    def change_group_name(self, guid, name):
        pass

    def change_group_bio(self, guid, bio):
        pass

    def change_group_name_bio(self, guid, name, bio):
        pass

    def auto_update_channel_name_bio(self, guid, bio_text, interval=60):
        while True:
            name = get_fancy_time()
            bio = f"{name}\n{bio_text}"
            self.change_channel_name_bio(guid, name, bio)
            time.sleep(interval)

    def auto_update_group_name_bio(self, guid, bio_text, interval=60):
        while True:
            name = get_fancy_time()
            bio = f"{name}\n{bio_text}"
            self.change_group_name_bio(guid, name, bio)
            time.sleep(interval)
