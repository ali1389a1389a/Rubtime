class RubTime:
    def __init__(self, token):
        self.token = token

    def change_channel_name(self, guid, name):
        pass

    def change_channel_bio(self, guid, bio):
        pass

    def change_channel_name_bio(self, guid, name, bio):
        pass

    def auto_update_channel_name(self, guid, interval=60):
        pass

    def auto_update_channel_name_bio(self, guid, bio_text, link="", interval=60):
        pass

    def change_group_name(self, guid, name):
        pass

    def change_group_bio(self, guid, bio):
        pass

    def change_group_name_bio(self, guid, name, bio):
        pass

    def auto_update_group_name(self, guid, interval=60):
        pass

    def auto_update_group_name_bio(self, guid, bio_text, link="", interval=60):
        pass
