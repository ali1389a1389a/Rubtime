from datetime import datetime

def to_fancy_numbers(text):
    fancy_digits = {
        "0": "𝟶", "1": "𝟷", "2": "𝟸", "3": "𝟹", "4": "𝟺",
        "5": "𝟻", "6": "𝟼", "7": "𝟽", "8": "𝟾", "9": "𝟿"
    }
    return ''.join(fancy_digits.get(c, c) for c in text)

def get_fancy_time():
    now = datetime.now()
    hour = to_fancy_numbers(now.strftime("%I"))
    minute = to_fancy_numbers(now.strftime("%M"))
    meridiem = now.strftime("%p").replace("AM", "𝓐𝓜").replace("PM", "𝓟𝓜")
    return f"ᗩͲ ϟ {hour}⫶{minute} {meridiem}≻"
